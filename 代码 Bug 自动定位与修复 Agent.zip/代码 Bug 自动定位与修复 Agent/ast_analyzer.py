from tree_sitter import Language, Parser
import os

class ASTAnalyzer:
    def __init__(self, language):
        self.language = language
        self.parser = Parser()
        
        # 加载对应的语言解析器
        if language == "python":
            from tree_sitter_python import language as python_language
            self.parser.set_language(python_language())
        elif language == "java":
            from tree_sitter_java import language as java_language
            self.parser.set_language(java_language())
        elif language == "javascript":
            from tree_sitter_javascript import language as javascript_language
            self.parser.set_language(javascript_language())
        else:
            raise ValueError(f"不支持的语言: {language}")
    
    def parse(self, code):
        """解析代码生成AST"""
        return self.parser.parse(bytes(code, "utf8"))
    
    def find_problem_locations(self, tree, errors, call_chain):
        """根据错误信息和调用链定位问题代码位置"""
        root_node = tree.root_node
        problem_locations = []
        
        for error in errors:
            # 找到错误所在的节点
            error_node = self._find_node_at_position(
                root_node,
                error.range["start"]["line"],
                error.range["start"]["character"]
            )
            
            if error_node:
                # 向上查找包含该节点的函数或方法
                function_node = self._find_enclosing_function(error_node)
                
                problem_locations.append({
                    "error_message": error.message,
                    "error_range": error.range,
                    "error_node_type": error_node.type,
                    "error_text": error_node.text.decode("utf8"),
                    "function_name": function_node.text.decode("utf8").splitlines()[0] if function_node else None,
                    "function_range": {
                        "start": {"line": function_node.start_point[0], "character": function_node.start_point[1]},
                        "end": {"line": function_node.end_point[0], "character": function_node.end_point[1]}
                    } if function_node else None,
                    "call_chain": call_chain.get(error.message, [])
                })
        
        return problem_locations
    
    def _find_node_at_position(self, node, line, character):
        """找到指定位置的节点"""
        if node.start_point[0] <= line <= node.end_point[0]:
            if node.start_point[0] == line and node.start_point[1] > character:
                return None
            if node.end_point[0] == line and node.end_point[1] < character:
                return None
            
            for child in node.children:
                result = self._find_node_at_position(child, line, character)
                if result:
                    return result
            
            return node
        
        return None
    
    def _find_enclosing_function(self, node):
        """找到包含指定节点的函数或方法"""
        current = node
        while current:
            if self.language == "python" and current.type in ["function_definition", "class_definition"]:
                return current
            elif self.language == "java" and current.type in ["method_declaration", "constructor_declaration"]:
                return current
            elif self.language == "javascript" and current.type in ["function_declaration", "arrow_function", "method_definition"]:
                return current
            
            current = current.parent
        
        return None