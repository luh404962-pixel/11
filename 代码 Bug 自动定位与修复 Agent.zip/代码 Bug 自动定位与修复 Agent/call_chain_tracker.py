class CallChainTracker:
    def __init__(self, language):
        self.language = language
    
    def track(self, tree, errors, code):
        """追踪错误的调用链"""
        call_chains = {}
        
        for error in errors:
            # 从错误信息中提取调用栈信息
            call_stack = self._extract_call_stack(error.message)
            
            if call_stack:
                call_chains[error.message] = call_stack
            else:
                # 如果没有调用栈，尝试从代码中推断
                call_chains[error.message] = self._infer_call_chain(tree, error, code)
        
        return call_chains
    
    def _extract_call_stack(self, error_message):
        """从错误信息中提取调用栈"""
        lines = error_message.splitlines()
        call_stack = []
        
        if self.language == "python":
            # Python 调用栈格式: File "filename", line X, in function_name
            for line in lines:
                if "File \"" in line and ", line " in line and ", in " in line:
                    parts = line.split(", ")
                    file_part = parts[0].replace("File \"", "").replace("\"", "")
                    line_part = parts[1].replace("line ", "")
                    function_part = parts[2].replace("in ", "")
                    
                    call_stack.append({
                        "file": file_part,
                        "line": int(line_part),
                        "function": function_part
                    })
        
        elif self.language == "java":
            # Java 调用栈格式: at package.Class.method(Class.java:X)
            for line in lines:
                if line.strip().startswith("at ") and "(" in line and ")" in line:
                    method_part = line.strip()[3:line.index("(")]
                    file_part = line[line.index("(")+1:line.index(":")]
                    line_part = line[line.index(":")+1:line.index(")")]
                    
                    call_stack.append({
                        "file": file_part,
                        "line": int(line_part),
                        "function": method_part
                    })
        
        elif self.language == "javascript":
            # JavaScript 调用栈格式: at function_name (filename:X:Y)
            for line in lines:
                if line.strip().startswith("at ") and "(" in line and ")" in line:
                    if "(" in line:
                        function_part = line.strip()[3:line.index("(")].strip()
                        file_line_part = line[line.index("(")+1:line.index(")")]
                        if ":" in file_line_part:
                            file_part, line_part, _ = file_line_part.split(":", 2)
                            
                            call_stack.append({
                                "file": file_part,
                                "line": int(line_part),
                                "function": function_part
                            })
        
        return call_stack
    
    def _infer_call_chain(self, tree, error, code):
        """从代码中推断调用链"""
        # 简化实现：找到错误所在的函数，然后查找所有调用该函数的地方
        root_node = tree.root_node
        error_line = error.range["start"]["line"]
        
        # 找到错误所在的函数
        error_node = self._find_node_at_line(root_node, error_line)
        if not error_node:
            return []
        
        function_node = self._find_enclosing_function(error_node)
        if not function_node:
            return []
        
        function_name = self._get_function_name(function_node)
        if not function_name:
            return []
        
        # 查找所有调用该函数的地方
        calls = self._find_function_calls(root_node, function_name)
        
        call_chain = [{
            "file": "current",
            "line": error_line + 1,
            "function": function_name
        }]
        
        for call in calls:
            call_chain.append({
                "file": "current",
                "line": call["line"] + 1,
                "function": call["caller"]
            })
        
        return call_chain
    
    def _find_node_at_line(self, node, line):
        """找到指定行的节点"""
        if node.start_point[0] <= line <= node.end_point[0]:
            for child in node.children:
                result = self._find_node_at_line(child, line)
                if result:
                    return result
            return node
        return None
    
    def _find_enclosing_function(self, node):
        """找到包含指定节点的函数"""
        current = node
        while current:
            if self.language == "python" and current.type in ["function_definition", "class_definition"]:
                return current
            elif self.language == "java" and current.type in ["method_declaration", "constructor_declaration"]:
                return current
            elif self.language == "javascript" and current.type in ["function_declaration", "arrow_function", "method_definition"]:
                return current
            current = current.parent
        return None
    
    def _get_function_name(self, function_node):
        """获取函数名称"""
        if self.language == "python":
            name_node = function_node.child_by_field_name("name")
        elif self.language == "java":
            name_node = function_node.child_by_field_name("name")
        elif self.language == "javascript":
            name_node = function_node.child_by_field_name("name")
        
        return name_node.text.decode("utf8") if name_node else None
    
    def _find_function_calls(self, node, function_name, calls=None):
        """查找所有调用指定函数的地方"""
        if calls is None:
            calls = []
        
        if node.type == "call_expression":
            identifier = node.child_by_field_name("function")
            if identifier and identifier.text.decode("utf8") == function_name:
                caller_node = self._find_enclosing_function(node)
                caller_name = self._get_function_name(caller_node) if caller_node else "global"
                
                calls.append({
                    "line": node.start_point[0],
                    "caller": caller_name
                })
        
        for child in node.children:
            self._find_function_calls(child, function_name, calls)
        
        return calls