const vscode = require('vscode');
const axios = require('axios');

let diagnosticCollection;
let currentFixes = new Map();

function activate(context) {
    console.log('AI Bug Fix Agent 已激活');
    
    diagnosticCollection = vscode.languages.createDiagnosticCollection('bug-fix-agent');
    
    let analyzeDisposable = vscode.commands.registerCommand(
        'bug-fix-agent.analyzeError',
        async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) {
                vscode.window.showErrorMessage('请先打开一个代码文件');
                return;
            }
            
            const document = editor.document;
            const fileName = document.fileName;
            const fileContent = document.getText();
            const language = document.languageId;
            
            // 获取当前文件的所有诊断信息
            const diagnostics = vscode.languages.getDiagnostics(document.uri);
            const errors = diagnostics.filter(d => d.severity === vscode.DiagnosticSeverity.Error);
            
            if (errors.length === 0) {
                vscode.window.showInformationMessage('当前文件没有检测到错误');
                return;
            }
            
            // 显示进度条
            await vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: 'AI Bug Fix Agent',
                cancellable: true
            }, async (progress, token) => {
                progress.report({ message: '正在分析错误...' });
                
                try {
                    const config = vscode.workspace.getConfiguration('bugFixAgent');
                    const backendUrl = config.get('backendUrl');
                    
                    const response = await axios.post(`${backendUrl}/api/analyze`, {
                        fileName,
                        fileContent,
                        language,
                        errors: errors.map(e => ({
                            message: e.message,
                            range: {
                                start: { line: e.range.start.line, character: e.range.start.character },
                                end: { line: e.range.end.line, character: e.range.end.character }
                            }
                        })),
                        config: {
                            apiKey: config.get('apiKey'),
                            model: config.get('model'),
                            autoRunTests: config.get('autoRunTests')
                        }
                    }, {
                        cancelToken: token
                    });
                    
                    if (response.data.success) {
                        const fixes = response.data.fixes;
                        currentFixes.set(fileName, fixes);
                        
                        // 显示修复选项
                        const items = fixes.map((fix, index) => ({
                            label: `方案 ${index + 1}: ${fix.title}`,
                            description: `测试通过率: ${fix.testPassRate}%`,
                            detail: fix.explanation,
                            fix: fix
                        }));
                        
                        const selected = await vscode.window.showQuickPick(items, {
                            placeHolder: '选择一个修复方案'
                        });
                        
                        if (selected) {
                            await applyFix(editor, selected.fix);
                        }
                    } else {
                        vscode.window.showErrorMessage(`分析失败: ${response.data.message}`);
                    }
                } catch (error) {
                    if (error.message === 'Canceled') {
                        vscode.window.showInformationMessage('分析已取消');
                    } else {
                        vscode.window.showErrorMessage(`分析出错: ${error.message}`);
                    }
                }
            });
        }
    );
    
    let applyDisposable = vscode.commands.registerCommand(
        'bug-fix-agent.applyFix',
        async () => {
            const editor = vscode.window.activeTextEditor;
            if (!editor) {
                vscode.window.showErrorMessage('请先打开一个代码文件');
                return;
            }
            
            const fileName = editor.document.fileName;
            const fixes = currentFixes.get(fileName);
            
            if (!fixes || fixes.length === 0) {
                vscode.window.showInformationMessage('没有可用的修复方案');
                return;
            }
            
            // 显示修复选项
            const items = fixes.map((fix, index) => ({
                label: `方案 ${index + 1}: ${fix.title}`,
                description: `测试通过率: ${fix.testPassRate}%`,
                detail: fix.explanation,
                fix: fix
            }));
            
            const selected = await vscode.window.showQuickPick(items, {
                placeHolder: '选择一个修复方案'
            });
            
            if (selected) {
                await applyFix(editor, selected.fix);
            }
        }
    );
    
    context.subscriptions.push(analyzeDisposable);
    context.subscriptions.push(applyDisposable);
}

async function applyFix(editor, fix) {
    const document = editor.document;
    
    await editor.edit(editBuilder => {
        // 应用代码变更
        fix.changes.forEach(change => {
            const range = new vscode.Range(
                change.range.start.line,
                change.range.start.character,
                change.range.end.line,
                change.range.end.character
            );
            editBuilder.replace(range, change.newText);
        });
    });
    
    // 显示修复说明
    vscode.window.showInformationMessage(`修复已应用: ${fix.title}\n\n${fix.explanation}`);
}

function deactivate() {
    if (diagnosticCollection) {
        diagnosticCollection.dispose();
    }
}

module.exports = {
    activate,
    deactivate
};