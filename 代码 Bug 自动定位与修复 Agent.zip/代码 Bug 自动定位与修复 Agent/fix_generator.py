from openai import OpenAI
import json

class FixGenerator:
    def __init__(self, api_key, model="gpt-4o"):
        self.client = OpenAI(api_key=api_key)
        self.model = model
    
    def generate_fixes(self, code, errors, problem_locations, call_chain, language):
        """生成多个修复方案"""
        fixes = []
        
        # 为每个问题位置生成修复方案
        for location in problem_locations:
            # 构建提示词
            prompt = self._build_prompt(code, location, call_chain, language)
            
            # 调用LLM生成修复方案
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "你是一个专业的代码修复专家。请分析以下代码错误并提供修复方案。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                response_format={"type": "json_object"}
            )
            
            try:
                result = json.loads(response.choices[0].message.content)
                
                if "fixes" in result:
                    for fix in result["fixes"]:
                        fixes.append({
                            "title": fix.get("title", "修复方案"),
                            "explanation": fix.get("explanation", ""),
                            "root_cause": fix.get("root_cause", ""),
                            "changes": fix.get("changes", []),
                            "testPassRate": 0.0
                        })
            except json.JSONDecodeError:
                continue
        
        # 如果没有生成足够的方案，生成一些通用修复
        if len(fixes) < 2:
            fixes.extend(self._generate_generic_fixes(code, errors, language))
        
        return fixes
    
    def _build_prompt(self, code, location, call_chain, language):
        """构建LLM提示词"""
        error_context = self._get_error_context(code, location)
        
        prompt = f"""
请分析以下{language}代码中的错误并提供3个不同的修复方案。

错误信息: {location['error_message']}

错误位置: 第{location['error_range']['start']['line'] + 1}行
错误代码: {location['error_text']}

包含错误的函数: {location['function_name']}

调用链:
{self._format_call_chain(location['call_chain'])}

完整代码上下文: