from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import os
import tempfile
import subprocess
import json
from ast_analyzer import ASTAnalyzer
from call_chain_tracker import CallChainTracker
from fix_generator import FixGenerator
from test_validator import TestValidator

app = FastAPI(title="Bug Fix Agent API")

class Range(BaseModel):
    start: Dict[str, int]
    end: Dict[str, int]

class ErrorInfo(BaseModel):
    message: str
    range: Range

class AnalyzeRequest(BaseModel):
    fileName: str
    fileContent: str
    language: str
    errors: List[ErrorInfo]
    config: Dict[str, str]

class CodeChange(BaseModel):
    range: Range
    oldText: str
    newText: str

class FixOption(BaseModel):
    title: str
    explanation: str
    changes: List[CodeChange]
    testPassRate: float
    rootCause: str

class AnalyzeResponse(BaseModel):
    success: bool
    message: Optional[str] = None
    fixes: Optional[List[FixOption]] = None

@app.post("/api/analyze", response_model=AnalyzeResponse)
async def analyze_error(request: AnalyzeRequest):
    try:
        # 初始化分析器
        ast_analyzer = ASTAnalyzer(request.language)
        call_chain_tracker = CallChainTracker(request.language)
        fix_generator = FixGenerator(
            api_key=request.config.get("apiKey", ""),
            model=request.config.get("model", "gpt-4o")
        )
        test_validator = TestValidator(request.language)
        
        # 步骤1: 解析代码生成AST
        ast = ast_analyzer.parse(request.fileContent)
        
        # 步骤2: 追踪错误调用链
        call_chain = call_chain_tracker.track(
            ast, 
            request.errors, 
            request.fileContent
        )
        
        # 步骤3: 定位问题代码并分析根因
        problem_locations = ast_analyzer.find_problem_locations(
            ast, 
            request.errors, 
            call_chain
        )
        
        # 步骤4: 生成多个修复方案
        candidate_fixes = fix_generator.generate_fixes(
            request.fileContent,
            request.errors,
            problem_locations,
            call_chain,
            request.language
        )
        
        # 步骤5: 验证修复方案
        validated_fixes = []
        for fix in candidate_fixes:
            # 应用修复到临时文件
            with tempfile.NamedTemporaryFile(
                mode='w', 
                suffix=os.path.splitext(request.fileName)[1], 
                delete=False
            ) as f:
                fixed_content = apply_changes(request.fileContent, fix["changes"])
                f.write(fixed_content)
                temp_file = f.name
            
            try:
                # 运行单元测试
                test_result = test_validator.run_tests(
                    temp_file,
                    request.fileName
                )
                
                fix["testPassRate"] = test_result["pass_rate"]
                validated_fixes.append(fix)
            finally:
                os.unlink(temp_file)
        
        # 按测试通过率排序
        validated_fixes.sort(key=lambda x: x["testPassRate"], reverse=True)
        
        # 转换为响应格式
        fixes = []
        for fix in validated_fixes[:3]:  # 只返回前3个最优方案
            fixes.append(FixOption(
                title=fix["title"],
                explanation=fix["explanation"],
                changes=[CodeChange(**change) for change in fix["changes"]],
                testPassRate=fix["testPassRate"],
                rootCause=fix["root_cause"]
            ))
        
        return AnalyzeResponse(
            success=True,
            fixes=fixes
        )
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

def apply_changes(content, changes):
    """应用代码变更"""
    # 将变更按行号从后往前排序，避免行号偏移问题
    sorted_changes = sorted(
        changes,
        key=lambda x: x["range"]["end"]["line"],
        reverse=True
    )
    
    lines = content.splitlines(keepends=True)
    
    for change in sorted_changes:
        start_line = change["range"]["start"]["line"]
        start_char = change["range"]["start"]["character"]
        end_line = change["range"]["end"]["line"]
        end_char = change["range"]["end"]["character"]
        
        # 处理单行变更
        if start_line == end_line:
            line = lines[start_line]
            new_line = line[:start_char] + change["newText"] + line[end_char:]
            lines[start_line] = new_line
        # 处理多行变更
        else:
            # 替换第一行
            lines[start_line] = lines[start_line][:start_char] + change["newText"]
            # 删除中间行
            del lines[start_line+1:end_line]
            # 替换最后一行
            if end_line < len(lines):
                lines[start_line+1] = lines[end_line][end_char:]
    
    return "".join(lines)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)